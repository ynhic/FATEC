package banco;

import static org.junit.Assert.*;

import org.junit.Test;

public class TesteConta {

	@Test
	public void testCreditar() {
		Conta teste = new Conta("1234", new Cliente("12345", "Marco"), 100);
		teste.creditar(100);
		assertEquals("R$100 com crédito de R$100 deve resultar em R$200",
				200, teste.obterSaldo(),0);
	}

	@Test
	public void testDebitar() {
		Conta teste = new Conta("1234", new Cliente("12345", "Marco"), 100);
		teste.debitar(100);
		assertEquals("R$100 com débito de R$100 deve resultar em R$0",
				0, teste.obterSaldo(),0);
	}

}
