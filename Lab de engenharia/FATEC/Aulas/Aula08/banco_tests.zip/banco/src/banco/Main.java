package banco;

public class Main {

	public static void main(String[] args) {
		Cliente c = new Cliente("1234567890", "João Carlos");
		c.abrirConta("0001", 1000);
		c.abrirConta("0002", 2000);
		c.exibir();
	}

}
