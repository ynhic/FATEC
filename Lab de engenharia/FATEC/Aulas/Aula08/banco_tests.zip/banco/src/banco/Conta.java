package banco;

public class Conta {
	private String numero;
	private double saldo;
	private Cliente cliente;

	public Conta(String numero, Cliente cliente, double saldo) {
		this.numero = numero;
		this.cliente = cliente;
		this.saldo = saldo;
	}

	public void creditar(double valor) {
		if (valor > 0)
			this.saldo += valor;
	}

	public void debitar(double valor) {
		if (valor > 0 && (this.saldo - valor) >= 0)
			this.saldo -= valor;
	}
	
	public double obterSaldo() {
		return this.saldo;
	}

	public void exibir() {
		System.out.println("Numero: " + this.numero + " CPF: "
				+ this.cliente.obterCpf() + " Nome: "
				+ this.cliente.obterNome() + " Saldo: " + this.saldo);
	}
}
