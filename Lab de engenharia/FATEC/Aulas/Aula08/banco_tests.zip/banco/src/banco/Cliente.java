package banco;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
	private List<Conta> contas;
	String cpf;
	String nome;

	public Cliente(String cpf, String nome) {
		this.cpf = cpf;
		this.nome = nome;
		this.contas = new ArrayList<Conta>();
	}

	public String obterCpf() {
		return this.cpf;
	}
	
	public String obterNome() {
		return this.nome;
	}
	
	public void abrirConta(String numero, double saldo) {
		Conta conta = new Conta(numero, this, saldo);
		contas.add(conta);
	}

	public void exibir() {
		System.out.println("CPF: " + this.cpf);
		System.out.println("Nome: " + this.nome);
		System.out.println("Contas deste cliente:");
		for (Conta c : contas)
			c.exibir();
	}
}
