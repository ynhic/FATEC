//(C) Joseph Mack 2011, jmack (at) wm7d (dot) net, released under GPL v3 (or any later version)

public class Main{

	public static void main(String[] args){

		RunMVC mainRunMVC = new RunMVC();

	} //main()

} //Main
